
<!DOCTYPE html>
<html>
<head>


	<title>My First Page</title>
</head>
<body>
<!-- content goes in the body -->
    <center>
        <h1>Titulo de la Tabla</h1>
        <p>
        Seleccione Curso
        <select id="Curso" name="CURSO">
            <option value="Matematicas" name="GEN1">Matematicas</option>
            <option value="Literatura" name="GEN2">Literatura</option>
            <option value="Biologia" name="GEN3">Biologia</option>
        </select>
        </p>
        </hr>
            <table border="1">
                <tbody>
<thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Apellido</th>
                        <th>Nombre</th>
                        <th>Nota 1</th> 
                        <th>Nota 2</th>
                        <th>Nota 3</th>
                        <th>Nota 4</th>
                        <th></th>      
                        <th>Promedio</th>
                        <th>Condición</th> 
                        <th></th> 
                    </tr>
                </thead><tr>
                        <td>75369852</td>
                        <td>ISABEL</td>
                        <td>B</td>
                        <td><input type='numero' name='N1'></td> 
                        <td><input type='numero' name='N2'></td>
                        <td><input type='numero' name='N3'></td>
                        <td><input type='numero' name='N4'></td>
                        <td> <input type='submit' name='calcular1' value='Calcular'></td>      
                        <td><input type='numero' name='P1'></td>
                        <td><input type='numero' name='C1'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
           </tr><tr>
                        <td>42263060</td>
                        <td>pablo ichpas</td>
                        <td>A</td>
                        <td><input type='numero' name='N5'></td> 
                        <td><input type='numero' name='N6'></td>
                        <td><input type='numero' name='N7'></td>
                        <td><input type='numero' name='N8'></td>
                        <td><input type='submit' name='calcular2' value='Calcular'></td>      
                        <td><input type='numero' name='P2'></td>
                        <td><input type='numero' name='C2'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    

          </tr><tr>
                        <td>40</td>
                        <td>genaro pablo velasquez</td>
                        <td>B</td>
                        <td><input type='numero' name='N9'></td> 
                        <td><input type='numero' name='N10'></td>
                        <td><input type='numero' name='N11'></td>
                        <td><input type='numero' name='N12'></td>
                        <td><input type='submit' name='calcular3' value='Calcular'></td>      
                        <td><input type='numero' name='P3'></td>
                        <td><input type='numero' name='C3'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
          </tr><tr>
                        <td>4</td>
                        <td>roxana</td>
                        <td>E</td>
                        <td><input type='numero' name='N13'></td> 
                        <td><input type='numero' name='N14'></td>
                        <td><input type='numero' name='N15'></td>
                        <td><input type='numero' name='N16'></td>
                        <td><input type='submit' name='calcular4' value='Calcular'></td>      
                        <td><input type='numero' name='P4'></td>
                        <td><input type='numero' name='C4'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
        </tr><tr>
                        <td>111</td>
                        <td>cesar</td>
                        <td>D</td>
                        <td><input type='numero' name='N17'></td> 
                        <td><input type='numero' name='N18'></td>
                        <td><input type='numero' name='N19'></td>
                        <td><input type='numero' name='N20'></td>
                        <td><input type='submit' name='calcular5' value='Calcular'></td>      
                        <td><input type='numero' name='P5'></td>
                        <td><input type='numero' name='C5'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
       </tr><tr>
                        <td>2</td>
                        <td>ruth de la cruz caceces</td>
                        <td>C</td>
                        <td><input type='numero' name='N21'></td> 
                        <td><input type='numero' name='N22'></td>
                        <td><input type='numero' name='N23'></td>
                        <td><input type='numero' name='N24'></td>
                        <td><input type='submit' name='calcular6' value='Calcular'></td>      
                        <td><input type='numero' name='P6'></td>
                        <td><input type='numero' name='C6'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
       </tr><tr>
                        <td>19990</td>
                        <td>carlos alberto</td>
                        <td>D</td>
                        <td><input type='numero' name='N25'></td> 
                        <td><input type='numero' name='N26'></td>
                        <td><input type='numero' name='N27'></td>
                        <td><input type='numero' name='N28'></td>
                        <td><input type='submit' name='calcular7' value='Calcular'></td>      
                        <td><input type='numero' name='P1'></td>
                        <td><input type='numero' name='C1'></td>
                        <td><input type='button' name='Guardar1' value='Guardar'></td>    
       </tr></tbody>
            </table>
            </br>        
    </center>
</body>
</html>
