<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>
    <form>
    Codigo: <input type="text" name="codigo"  maxlength="3" />
    <br/>

    Descripcion: <input type="text" name="descripcion" maxlength="200"/>
    Unidad:<input type="text" name="unidad(libras, kilos,paquetes,etc)" maxlength="20"/>
    <label> Ingrese la cantidad</label><br>
    <input type="number" name="cantidad"><br>
    <label> Ingrese precio</label><br>
    <input type="number" name="precio"><br>
    <button type="submit">ver total</button>
</form>
</body>
</html>
