<!DOCTYPE html>
<html lang="es">
<head>
    <title>Sumatoria Especial</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Sumatoria Especial</h1>
    <form name="formulario" method="post" action="w_series.php">
        Serie: 1 - 3 + 5 - 7 + ........ N
        </br>
        <input type="number" name="NMAX" placeholder="Numero">
        </br>
        <input type="submit" value="Calcular sumatoria">
    </form>
</body>
</html>
