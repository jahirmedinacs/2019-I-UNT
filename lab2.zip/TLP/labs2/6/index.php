<!DOCTYPE html>
<html>
<head>
	<title>Serie Invertida</title>
	<meta charset="utf-8">
</head>
<body>
    </h1>Serie Invertida</h1>
	<form name="formulario" action="s_inverted.php" method="post">
		Numero entre 0 y 100: <input type="number" name="NMAX" value="Numero" max="100" min="0">
		<br>
		<input type="submit" name="mostrar" value="Generar Serie">
	</form>
</body>
</html>
