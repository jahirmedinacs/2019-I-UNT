<!DOCTYPE html>
<html lang = "es">
<head>
	<title>Numeros Impares</title>
	<meta charset="utf-8">
</head>
<body>
    <h1>Numeros Impares</h1>
	<form name ="formulario" action="serie.php" method = "post" >
        </br>
        Ingrese el numero de elementos para generar la lista:
        </br>
	<input type="number" name="NMAX" placeholder="Numero">
	<input type="submit" name="boton" value="Aceptar">
    </br>
    </br>
	</form>
</body>
</html>
