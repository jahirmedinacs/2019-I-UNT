<!DOCTYPE html>
<html>
<head>
    <title>Serie de Fibonacci Factorial</title>
</head>
<body>
    <h1>Serie de Fibonacci Factorial</h1>
    <section>
    <form action="fib_fact.php" method="post">
        <input type="number" name="NMAX" placeholder="Numero de Elementos">
        <input type="submit" name="calcular" value="Generar">
    </form>
    </section>
</body>
</html>
