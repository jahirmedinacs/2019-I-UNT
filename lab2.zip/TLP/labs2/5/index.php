<!DOCTYPE html>
<html>
<head>
    <title>Serie de Potencias</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Serie de Potencia</h1>
    <form name="formulario" action="s_potent.php" method="post">
        <input type="number" name="N" placeholder="Base"><br>
        <input type="number" name="M" placeholder="Potencias"><br>
        <input type="submit" name="GENERATE" value="Mostrar serie">
    </form>
</body>
</html>
