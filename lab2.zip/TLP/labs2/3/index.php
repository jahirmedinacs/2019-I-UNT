<!DOCTYPE html>
<html>
<head>
    <title>Series Impares Factoriales</title>
</head>
<body>
<body>
    <h1>Series Impares Factoriales</h1>
    <section>
    <form action="s_factorial.php" method="post">
        <input type="numero" name="NMAX" placeholder="Ingrese el Numero Maximo">
        <input type="submit" name="calcular" value="Generar">
    </form>
    </section>
</body>
</html>

