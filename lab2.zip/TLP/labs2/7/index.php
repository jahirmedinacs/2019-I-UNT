<!DOCTYPE html>
<html lang="es">
<head>
    <title>Piramide</title>
    <meta charset="utf-8">
</head>
<body>
    <h1>Piramide de  Puntos</h1>
    <form name = "formulario" action="piramid.php" method="post">
    Numero de Filas? <br>
    <input type="number" name="NMAX" placeholder="Filas">
    <input type="submit" name="boton" value="Generar">
    </form>
</body>
</html>
